from flask import Flask, render_template, request, url_for, redirect, render_template, session, jsonify
import json
import requests
import numpy as np
import pandas as pd
import cv2
import base64
from io import BytesIO
from PIL import Image
import sys
import os
from predict import get_prediction, load_data 

# sfas_path = os.path.join(os.path.dirname(__file__), '../face-attendance-system/SilentFaceAntiSpoofing')
# sys.path.append(sfas_path)
# from custom_test import test

app = Flask(__name__)
app.secret_key = 'your_secret_key'

DISEASE = 'Jantung' ## Global

@app.route('/clear-session')
def clear_session():
    session.clear()
    return render_template('landing_page.html')


@app.route('/', methods=['GET', 'POST'])
def landing_page():
    return render_template('landing_page.html')

@app.route('/dashboard_prediksi_penyakit', methods=['GET', 'POST'])
def dashboard_prediksi_penyakit():
    title = 'Healtcare Assistance'
    prediction_text = session.get('prediction', {
        'heart': "Belum Dijalankan",
        'diabetes': "Belum Dijalankan",
        'lung': "Belum Dijalankan",
        'stroke': "Belum Dijalankan"
    })
    if prediction_text['heart'] == 'Belum Dijalankan':
        return render_template('index_dashboard_prediksi_penyakit.html', title=title, prediction = prediction_text)
    else :
        return render_template('index sudah cek.html', title=title, prediction = prediction_text)

@app.route('/payment', methods=['GET', 'POST'])
def payment():
    return render_template('payment.html')

@app.route('/payment_virtual_account', methods=['GET', 'POST']) 
def payment_virtual_account():
    title = 'Virtual Account Payment'
    app = request.args.get('app')
    role = request.args.get('role')
    statusPengajuanPembayaran = request.args.get('statusPengajuanPembayaran')
    return render_template('virtual_account_faskes.html', title=title, app= app, role=role, statusPengajuanPembayaran=statusPengajuanPembayaran)

@app.route("/predict", methods=['GET', 'POST'])
def predict():
    title = 'Integrated Tracking'
    app = request.args.get('app')
    role = request.args.get('role')
    return render_template("prediksi.html", app = app, title=title, role=role)

@app.route("/fraud_detection", methods=['GET', 'POST'])
def fraud_detection():
    title = 'Fraud Detection'
    app = request.args.get('app')
    role = request.args.get('role')
    return render_template("fraud_detection.html", app = app,role=role, title=title,)

@app.route("/predict_for_virtual_account_faskes", methods=['GET', 'POST'])
def predict_for_virtual_account_faskes():
    title = 'Virtual Account Payment'
    nama = request.args.get('nama')
    app = request.args.get('app')
    role = request.args.get('role')
    no_bpjs = request.args.get('no_bpjs')
    return render_template("prediksi_for_virtual_account_faskes.html", nama=nama, no_bpjs=no_bpjs, title=title, app=app, role=role)

@app.route('/virtual_account_faskes', methods=['GET', 'POST'])
def virtual_account_faskes():
    title = 'Virtual Account Payment'
    role = request.args.get('role')
    app_name = request.args.get('app')
    return render_template('virtual_account_faskes.html', title=title , role=role, app=app_name)

@app.route('/virtual_account_user', methods=['GET', 'POST']) 
def virtual_account_user():
    title = 'Virtual Account Payment'
    role = request.args.get('role')
    app = request.args.get('app')
    status_pemeriksaan = request.args.get('statusPemeriksaan')
    status_komplain = request.args.get('statusKomplain')
    return render_template('virtual_account_user.html', title=title , role=role, app=app, status_pemeriksaan=status_pemeriksaan, status_komplain=status_komplain)

@app.route("/predictcopy", methods=['GET', 'POST'])
def predictcopy():
    return render_template("prediksi_copy.html", hasil=hasil, title='predict', prediction=prediction_text)

@app.route('/process_image', methods=['POST'])
def process_image():
    data = request.get_json() # Get raw data, not parsed JSON
    image_data = data.get('image_data')

    # Decode base64 image data and convert to OpenCV format
    image = Image.open(BytesIO(base64.b64decode(image_data.split(',')[1])))
    image = cv2.cvtColor(np.array(image), cv2.COLOR_RGB2BGR)
    print("image shape", image.shape)
    height, width, _ = image.shape
    print(f"Image dimensions: {height} x {width}")

    # Calculate the new width to maintain the 4:3 aspect ratio
    new_height = int((width * 4) / 3)

    # Resize the image while maintaining the original height
    resized_image = cv2.resize(image, (width, new_height))
    # print(f"resized_image dimensions: {width} x {new_height}")

    # label_result = test(
    #     resized_image,
    #     model_dir='/Users/pajak/Documents/MoF-DAC/1. Hackathon/9. BPJS Healthkathon 2023 (DGY + AYA)/BPJS_2023/face-attendance-system/SilentFaceAntiSpoofing/resources/anti_spoof_models',
    #     device_id=0
    # ) 
    
    label_result = "Valid" 
    result = str(label_result) 
    return jsonify({'result': result})

@app.route("/prediksi_penyakit", methods=['GET', 'POST'])
def prediksi_penyakit():
    if request.method == 'POST':
        try:
            # [berat badan (kg) : (tinggi badan (m) x tinggi badan (m))]
            BMI = int(request.form.get('WEIGHT'))/(int(request.form.get('HEIGHT'))  / 100 *int(request.form.get('HEIGHT')) / 100)
            formlist = ['GENDER','AGE_GROUP','BMI','HIGHCHOL','HIGHBP','PHYSACTIVITY','ALCOHOL','FRUITS','VEGGIES','SMOKING','YELLOW_FINGERS','COUGHING','SHORT_BREATH']
            float_features = [request.form.get(x) for x in formlist]
            float_features[2] = int(BMI*10)/10
            # float_features = [float(x) for x in request.form.values()]
            df = load_data(float_features)
            models = ['model_heart','model_diabetes','model_lung','model_stroke']
            prediction = [get_prediction(f'front-end/models/{x}.sav',df) for x in models]   
            # prediction = [get_prediction(f'models/{x}.sav',df) for x in models]   
            # print("prediction", prediction)
            if BMI < 18.5:
                kelas = "Underweight"
            elif 18.5 <= BMI < 25:
                kelas = "Normal"
            elif 25 <= BMI < 30:
                kelas = "Overweight"
            else:
                kelas = "obesitas"    
            hasil = {
                'name': int(BMI*10)/10,
                'kelas':kelas
            }
            prediction_text = {
                'heart': ["Rendah" if prediction[0]==0 else "Tinggi"][0],
                'diabetes':["Tinggi" if prediction[1] == 2 else "Rendah"][0],
                'lung': ["Rendah" if prediction[2]==0 else "Tinggi"][0],
                'stroke':["Rendah" if prediction[3]==0 else "Tinggi"][0]
            }
            session['prediction'] = prediction_text
        except:
            hasil = {
            'name': "Kesalahan Pengisian Parameter",
            'kelas': "-"
            }
            prediction_text = {
                'heart': "Belum Dijalankan",
                'diabetes':"Belum Dijalankan",
                'lung': "Belum Dijalankan",
                'stroke':"Belum Dijalankan"
            }
        return render_template("prediksi_penyakit.html",hasil=hasil,title='Prediksi Penyakit', prediction = prediction_text)
    
    else:
        hasil = {
        'name': "Belum Dijalankan",
        'kelas': "-"
        }
        prediction_text = {
            'heart': "Belum Dijalankan",
            'diabetes':"Belum Dijalankan",
            'lung': "Belum Dijalankan",
            'stroke':"Belum Dijalankan"
        }
        return render_template("prediksi_penyakit.html",hasil=hasil,title='Prediksi Penyakit', prediction = prediction_text)
    
@app.route('/dashboard_jantung', methods=['GET', 'POST'])
def dashboard_jantung():
    title = 'Prediksi Penyakit'
    global DISEASE
    DISEASE = 'Jantung'
    return render_template('index_jantung.html', title=title, disease=DISEASE)

@app.route('/dash2', methods=['GET', 'POST'])
def dashboard2():
    title = 'Prediksi Penyakit'
    global DISEASE
    DISEASE = 'Diabetes'
    return render_template('index_db.html', title=title, disease=DISEASE)

@app.route('/dash3', methods=['GET', 'POST'])
def dashboard3():
    title = 'Prediksi Penyakit'
    global DISEASE
    DISEASE = 'Kanker Paru-Paru'
    return render_template('index_lc.html', title=title, disease=DISEASE)

@app.route('/dash4', methods=['GET', 'POST'])
def dashboard4():
    title = 'Prediksi Penyakit'
    global DISEASE
    DISEASE = 'Stroke'
    return render_template('index_st.html', title=title, disease=DISEASE)

@app.route('/dashboard', methods=['GET', 'POST'])
def dashboard():
    title = 'dashboard'
    app = request.args.get('app')
    role = request.args.get('role')
    # status_pemeriksaan= request.args.get('statusPemeriksaan')
    # if role == 'kantor_pusat':
    #     return render_template('dashboard_kanpus.html', title=title, role=role, app=app, status_pemeriksaan=status_pemeriksaan)
    # else:
    return render_template('prediksi_dashboard.html', title=title, app=app, role=role)

@app.route("/analytics", methods=['GET', 'POST'])
def analytics():
    title = 'Analytics'
    app = request.args.get('app')
    role = request.args.get('role')
    return render_template("analytics.html", app = app, title=title, role=role)

@app.route("/chronics", methods=['GET', 'POST'])
def chronics():
    title = 'Chronics'
    app = request.args.get('app')
    role = request.args.get('role')
    return render_template("chronics.html", app = app, title=title, role=role)

@app.route('/rekomendasi_makanan', methods=['GET', 'POST'])
def rekomendasi_makanan():
    title = 'Recommendation'
    role = request.args.get('role')
    app = request.args.get('app')
    return render_template('prediksi_rekomendasi.html', title=title, app=app, role=role)


@app.route("/prediksi_makanan", methods=['GET', 'POST'])
def prediksi_makanan():
    title = 'Computer Vision'
    app = request.args.get('app')
    role = request.args.get('role')
    return render_template("prediksi_makanan.html", app = app, title=title, role=role)

    