import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import RobustScaler as rs
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
import joblib


def load_data(data_list):
  data = pd.DataFrame([data_list], columns=['GENDER','AGE_GROUP','BMI','HIGHCHOL','HIGHBP','PHYSACTIVITY','ALCOHOL','FRUITS','VEGGIES','SMOKING','YELLOW_FINGERS','COUGHING','SHORT_BREATH'])
  return data

def get_prediction(model_url,df):
  print(model_url)
  loaded_model = joblib.load(model_url)
  result = loaded_model.predict(df)
  return result[0]
